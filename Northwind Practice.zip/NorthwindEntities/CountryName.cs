﻿namespace NorthwindEntities
{
    public class CountryName
    {
        public string Country { get; set; }
    }
}
