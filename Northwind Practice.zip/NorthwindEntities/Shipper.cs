﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; // for [Key] attribute
using System.ComponentModel.DataAnnotations.Schema; // [Table()] and [NotMapped]
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NorthwindEntities
{
    [Table("Shippers")] // Maps my class to the Shippers table in the database
    public class ShippingCompany
    {
        [Key]
        public int ShipperID { get; set; }
        // TODO: Come back 
    }
}
